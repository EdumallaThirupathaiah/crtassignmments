import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <div className="nav">
      <h3>IT HelpDesk</h3>
      <div>
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
        <Link to="/signup">Signup</Link>
      </div>
    </div>
  )
}
