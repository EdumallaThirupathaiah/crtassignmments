import { useState } from 'react'

export default function Signup() {
  const [user, setUser] = useState({ name:'', email:'', password:'', dept:'', empid:'' })

  const register = () => {
    const users = JSON.parse(localStorage.getItem('users')) || []
    users.push(user)
    localStorage.setItem('users', JSON.stringify(users))
    alert('Registered Successfully')
  }

  return (
    <div className="box">
      <input placeholder="Name" onChange={e=>setUser({...user,name:e.target.value})}/>
      <input placeholder="Email" onChange={e=>setUser({...user,email:e.target.value})}/>
      <input type="password" placeholder="Password" onChange={e=>setUser({...user,password:e.target.value})}/>
      <input placeholder="Department" onChange={e=>setUser({...user,dept:e.target.value})}/>
      <input placeholder="Employee ID" onChange={e=>setUser({...user,empid:e.target.value})}/>
      <button onClick={register}>Signup</button>
    </div>
  )
}
