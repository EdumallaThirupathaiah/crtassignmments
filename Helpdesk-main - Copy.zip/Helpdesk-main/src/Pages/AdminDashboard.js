import { useState } from 'react'

export default function AdminDashboard() {
  const [tickets,setTickets] = useState(JSON.parse(localStorage.getItem('tickets')) || [])

  const updateStatus = (id,status) => {
    const updated = tickets.map(t=>t.id===id?{...t,status}:t)
    setTickets(updated)
    localStorage.setItem('tickets', JSON.stringify(updated))
  }

  return (
    <div>
      {tickets.map(t=>(
        <div key={t.id} className="card">
          <h4>{t.title}</h4>
          <select onChange={e=>updateStatus(t.id,e.target.value)}>
            <option>Open</option>
            <option>In Progress</option>
            <option>Closed</option>
          </select>
        </div>
      ))}
    </div>
  )
}
