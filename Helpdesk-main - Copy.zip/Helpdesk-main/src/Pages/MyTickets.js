export default function MyTickets() {
  const tickets = JSON.parse(localStorage.getItem('tickets')) || []

  return (
    <div>
      {tickets.map(t=>(
        <div key={t.id} className="card">
          <h4>{t.title}</h4>
          <p>{t.priority}</p>
          <p>{t.status}</p>
        </div>
      ))}
    </div>
  )
}
