import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <div className="home">
      <h1>IT HelpDesk Portal</h1>
      <p>Submit and track IT support requests easily</p>
      <div className="home-buttons">
        <Link to="/login">Employee Login</Link>
        <Link to="/signup">Employee Signup</Link>
        <Link to="/admin">Admin Login</Link>
      </div>
    </div>
  )
}
