import { Link } from 'react-router-dom'

export default function Dashboard() {
  return (
    <div className="box">
      <Link to="/submit">Submit Ticket</Link>
      <Link to="/tickets">My Tickets</Link>
    </div>
  )
}
