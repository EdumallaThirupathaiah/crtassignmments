import { useState } from 'react'

export default function SubmitTicket() {
  const [ticket,setTicket] = useState({ title:'', desc:'', priority:'Low', dept:'' })

  const submit = () => {
    const tickets = JSON.parse(localStorage.getItem('tickets')) || []
    tickets.push({ ...ticket, id:Date.now(), status:'Open' })
    localStorage.setItem('tickets', JSON.stringify(tickets))
    alert('Ticket Submitted')
  }

  return (
    <div className="box">
      <input placeholder="Issue Title" onChange={e=>setTicket({...ticket,title:e.target.value})}/>
      <textarea placeholder="Description" onChange={e=>setTicket({...ticket,desc:e.target.value})}></textarea>
      <select onChange={e=>setTicket({...ticket,priority:e.target.value})}>
        <option>Low</option>
        <option>Medium</option>
        <option>High</option>
      </select>
      <input placeholder="Department" onChange={e=>setTicket({...ticket,dept:e.target.value})}/>
      <button onClick={submit}>Submit</button>
    </div>
  )
}
