import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const nav = useNavigate()

  const login = () => {
    if(email==='admin@techserve.com' && password==='admin123') {
      nav('/admin')
      return
    }
    const users = JSON.parse(localStorage.getItem('users')) || []
    const found = users.find(u=>u.email===email && u.password===password)
    if(found){
      localStorage.setItem('login', JSON.stringify(found))
      nav('/dashboard')
    } else {
      alert('Invalid Login')
    }
  }

  return (
    <div className="box">
      <input placeholder="Email" onChange={e=>setEmail(e.target.value)}/>
      <input type="password" placeholder="Password" onChange={e=>setPassword(e.target.value)}/>
      <button onClick={login}>Login</button>
    </div>
  )
}
