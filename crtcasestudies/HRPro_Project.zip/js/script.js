// Dashboard Count
if(document.getElementById("totalEmp")){
let emp=JSON.parse(localStorage.getItem("employees"))||[];
document.getElementById("totalEmp").innerText=emp.length;
}

// Employees
function addEmployee(){
let name=document.getElementById("empName").value;
let dept=document.getElementById("empDept").value;
let role=document.getElementById("empRole").value;
let contact=document.getElementById("empContact").value;
if(!name||!dept||!role||!contact){alert("Fill all fields");return;}
let emp=JSON.parse(localStorage.getItem("employees"))||[];
emp.push({name,dept,role,contact});
localStorage.setItem("employees",JSON.stringify(emp));
location.reload();
}

function renderEmployees(){
if(!document.getElementById("empTable")) return;
let search=document.getElementById("searchEmp")?.value.toLowerCase()||"";
let emp=JSON.parse(localStorage.getItem("employees"))||[];
let table=document.getElementById("empTable");
table.innerHTML="<tr><th>Name</th><th>Department</th><th>Role</th><th>Contact</th><th>Action</th></tr>";
emp.filter(e=>e.name.toLowerCase().includes(search)).forEach((e,i)=>{
table.innerHTML+=`<tr>
<td>${e.name}</td>
<td>${e.dept}</td>
<td>${e.role}</td>
<td>${e.contact}</td>
<td><button onclick="deleteEmp(${i})">Delete</button></td>
</tr>`;
});
}
renderEmployees();

function deleteEmp(i){
let emp=JSON.parse(localStorage.getItem("employees"));
emp.splice(i,1);
localStorage.setItem("employees",JSON.stringify(emp));
location.reload();
}

// Attendance
if(document.getElementById("attTable")){
let att=JSON.parse(localStorage.getItem("attendance"))||[];
att.forEach(a=>{
document.getElementById("attTable").innerHTML+=
`<tr><td>${a.name}</td><td>${a.status}</td><td>${a.date}</td></tr>`;
});
}

function markAttendance(){
let name=document.getElementById("attName").value;
let status=document.getElementById("attStatus").value;
let date=new Date().toLocaleDateString();
let att=JSON.parse(localStorage.getItem("attendance"))||[];
att.push({name,status,date});
localStorage.setItem("attendance",JSON.stringify(att));
location.reload();
}

// Payroll
function calculateSalary(){
let name=document.getElementById("payName").value;
let basic=Number(document.getElementById("basic").value);
let allow=Number(document.getElementById("allow").value);
let deduct=Number(document.getElementById("deduct").value);
if(!name||!basic){alert("Enter details");return;}
let net=basic+allow-deduct;
document.getElementById("netSalary").innerText=
"Net Salary for "+name+" = ₹"+net;
}

// Login (Simple)
function login(){
let email=document.getElementById("email").value;
let pass=document.getElementById("password").value;
if(email&&pass){
alert("Login Successful");
window.location="index.html";
}else{alert("Enter credentials");}
}