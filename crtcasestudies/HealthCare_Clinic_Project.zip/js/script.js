function signup() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let confirm = document.getElementById("confirm").value;
    let phone = document.getElementById("phone").value;

    if (!name || !email || !password || !confirm || !phone) {
        alert("Fill all fields");
        return;
    }

    if (password !== confirm) {
        alert("Passwords do not match");
        return;
    }

    localStorage.setItem("patient", JSON.stringify({name,email,password,phone}));
    alert("Signup Successful");
    window.location.href = "login.html";
}

function login() {
    let email = document.getElementById("loginEmail").value;
    let password = document.getElementById("loginPassword").value;

    let patient = JSON.parse(localStorage.getItem("patient"));

    if (patient && patient.email === email && patient.password === password) {
        alert("Login Successful");
        window.location.href = "index.html";
    } else {
        alert("Invalid Login");
    }
}

function searchDoctor() {
    let input = document.getElementById("search").value.toLowerCase();
    let cards = document.getElementsByClassName("card");

    for (let i = 0; i < cards.length; i++) {
        let text = cards[i].innerText.toLowerCase();
        cards[i].style.display = text.includes(input) ? "inline-block" : "none";
    }
}

function bookAppointment() {
    let name = document.getElementById("patientName").value;
    let doctor = document.getElementById("doctor").value;
    let date = document.getElementById("date").value;
    let time = document.getElementById("time").value;

    if (!name || !date || !time) {
        alert("Fill all details");
        return;
    }

    let appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    appointments.push({name, doctor, date, time});
    localStorage.setItem("appointments", JSON.stringify(appointments));

    alert("Appointment Booked");
    location.reload();
}

if (document.getElementById("appointmentTable")) {
    let appointments = JSON.parse(localStorage.getItem("appointments")) || [];
    appointments.forEach((a, index) => {
        document.getElementById("appointmentTable").innerHTML +=
        `<tr>
            <td>${a.name}</td>
            <td>${a.doctor}</td>
            <td>${a.date}</td>
            <td>${a.time}</td>
            <td><button onclick="cancelAppointment(${index})">Cancel</button></td>
        </tr>`;
    });
}

function cancelAppointment(index) {
    let appointments = JSON.parse(localStorage.getItem("appointments"));
    appointments.splice(index,1);
    localStorage.setItem("appointments", JSON.stringify(appointments));
    location.reload();
}

function contact() {
    alert("Message Sent Successfully");
}