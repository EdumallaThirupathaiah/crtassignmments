function signup() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (name == "" || email == "" || password == "") {
        alert("Please fill all fields");
        return;
    }

    let user = { name, email, password };
    localStorage.setItem("user", JSON.stringify(user));

    alert("Signup Successful!");
    window.location.href = "login.html";
}

function login() {
    let email = document.getElementById("loginEmail").value;
    let password = document.getElementById("loginPassword").value;

    let savedUser = JSON.parse(localStorage.getItem("user"));

    if (savedUser && email == savedUser.email && password == savedUser.password) {
        alert("Login Successful!");
        localStorage.setItem("loggedIn", true);
        window.location.href = "index.html";
    } else {
        alert("Invalid Credentials");
    }
}

function addToCart(name, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({ name, price });
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Product Added to Cart");
}

if (document.getElementById("cartItems")) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = 0;

    cart.forEach(item => {
        document.getElementById("cartItems").innerHTML +=
            `<p>${item.name} - ₹${item.price}</p>`;
        total += item.price;
    });

    document.getElementById("total").innerText = "Total: ₹" + total;
}