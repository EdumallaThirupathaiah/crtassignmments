function signup() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (name == "" || email == "" || password == "") {
        alert("Fill all fields");
        return;
    }

    localStorage.setItem("user", JSON.stringify({name,email,password}));
    alert("Signup Successful");
    window.location.href = "login.html";
}

function login() {
    let email = document.getElementById("loginEmail").value;
    let password = document.getElementById("loginPassword").value;

    let user = JSON.parse(localStorage.getItem("user"));

    if (user && user.email == email && user.password == password) {
        alert("Login Successful");
        window.location.href = "index.html";
    } else {
        alert("Invalid Login");
    }
}

function issueBook(title, author) {
    let issued = JSON.parse(localStorage.getItem("issued")) || [];
    let date = new Date().toLocaleDateString();
    issued.push({title, author, date});
    localStorage.setItem("issued", JSON.stringify(issued));
    alert("Book Issued");
}

if (document.getElementById("issuedList")) {
    let issued = JSON.parse(localStorage.getItem("issued")) || [];
    if (issued.length == 0) {
        document.getElementById("issuedList").innerHTML = "<p>No Books Issued</p>";
    } else {
        issued.forEach((book, index) => {
            document.getElementById("issuedList").innerHTML +=
            `<p>${book.title} by ${book.author} (Issued: ${book.date}) 
            <button onclick="returnBook(${index})">Return</button></p>`;
        });
    }
}

function returnBook(index) {
    let issued = JSON.parse(localStorage.getItem("issued"));
    issued.splice(index,1);
    localStorage.setItem("issued", JSON.stringify(issued));
    location.reload();
}

function contact() {
    alert("Message Sent Successfully");
}