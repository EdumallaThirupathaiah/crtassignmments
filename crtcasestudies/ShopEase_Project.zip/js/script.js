const products = [
{id:1,name:"Apple",price:100,category:"Fruits"},
{id:2,name:"Banana",price:60,category:"Fruits"},
{id:3,name:"Carrot",price:40,category:"Vegetables"}
];

function renderProducts(){
if(!document.getElementById("productList")) return;
let search = document.getElementById("search").value.toLowerCase();
let category = document.getElementById("categoryFilter").value;
let list = document.getElementById("productList");
list.innerHTML="";
products.filter(p=>
p.name.toLowerCase().includes(search) &&
(category==="all"||p.category===category)
).forEach(p=>{
list.innerHTML+=`
<div class="card">
<h3>${p.name}</h3>
<p>₹${p.price}</p>
<p>${p.category}</p>
<button onclick="addToCart(${p.id})">Add to Cart</button>
<button onclick="addToWishlist(${p.id})">Wishlist</button>
</div>`;
});
}

function addToCart(id){
let cart=JSON.parse(localStorage.getItem("cart"))||[];
let item=products.find(p=>p.id===id);
cart.push({...item,qty:1});
localStorage.setItem("cart",JSON.stringify(cart));
alert("Added to Cart");
}

function addToWishlist(id){
let wish=JSON.parse(localStorage.getItem("wishlist"))||[];
let item=products.find(p=>p.id===id);
wish.push(item);
localStorage.setItem("wishlist",JSON.stringify(wish));
alert("Added to Wishlist");
}

if(document.getElementById("cartItems")){
let cart=JSON.parse(localStorage.getItem("cart"))||[];
let total=0;
cart.forEach((item,i)=>{
total+=item.price*item.qty;
document.getElementById("cartItems").innerHTML+=`
<p>${item.name} - ₹${item.price} x ${item.qty}
<button onclick="removeCart(${i})">Remove</button></p>`;
});
let tax=total*0.05;
document.getElementById("cartTotal").innerText=
"Subtotal: ₹"+total+" | Tax: ₹"+tax+" | Total: ₹"+(total+tax);
}

function removeCart(i){
let cart=JSON.parse(localStorage.getItem("cart"));
cart.splice(i,1);
localStorage.setItem("cart",JSON.stringify(cart));
location.reload();
}

if(document.getElementById("wishlistItems")){
let wish=JSON.parse(localStorage.getItem("wishlist"))||[];
wish.forEach((item,i)=>{
document.getElementById("wishlistItems").innerHTML+=`
<p>${item.name} - ₹${item.price}
<button onclick="moveToCart(${i})">Move to Cart</button>
<button onclick="removeWish(${i})">Remove</button></p>`;
});
}

function moveToCart(i){
let wish=JSON.parse(localStorage.getItem("wishlist"));
let cart=JSON.parse(localStorage.getItem("cart"))||[];
cart.push({...wish[i],qty:1});
wish.splice(i,1);
localStorage.setItem("cart",JSON.stringify(cart));
localStorage.setItem("wishlist",JSON.stringify(wish));
location.reload();
}

function removeWish(i){
let wish=JSON.parse(localStorage.getItem("wishlist"));
wish.splice(i,1);
localStorage.setItem("wishlist",JSON.stringify(wish));
location.reload();
}

function signup(){
let name=document.getElementById("name").value;
let email=document.getElementById("sEmail").value;
let pass=document.getElementById("sPassword").value;
let confirm=document.getElementById("confirm").value;
if(!name||!email||!pass||pass!==confirm){alert("Check details");return;}
localStorage.setItem("user",JSON.stringify({name,email,pass}));
alert("Signup Successful");
window.location="login.html";
}

function login(){
let email=document.getElementById("email").value;
let pass=document.getElementById("password").value;
let user=JSON.parse(localStorage.getItem("user"));
if(user&&user.email===email&&user.pass===pass){
alert("Login Successful");
window.location="index.html";
}else{alert("Invalid Login");}
}

renderProducts();